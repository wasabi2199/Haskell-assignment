module Main where
import Text.HTML.TagSoup
import System.Directory
import Control.Monad
import System.IO
import Data.List
import Data.Maybe
import Control.Parallel.Strategies
import Text.Regex

findString :: (Eq a) => [a] -> [a] -> Maybe Int
findString search str = findIndex (isPrefixOf search) (tails str)

testFunc = do
  writeFile "tmp.txt" ""
  handle <- readFile "./html_pages2/aaa2.txt"
  let fstParse = parseTags handle
  if length fstParse > 1 then do
    forM fstParse $ \tag -> do
      case maybeTagText tag of
              Just str -> appendFile "tmp.txt" str
              Nothing -> appendFile "tmp.txt" ""
    tmp <- readFile "tmp.txt"
    writeFile "./html_pages2/aaa2.txt" tmp
    removeFile "tmp.txt"
    testFunc
  else return ()

getBody :: String -> Maybe String
getBody handle = case findString "<body" handle of
    (Just val1) -> case getEndBody $ snd $ splitAt val1 handle of
      (Just a) -> Just a
      Nothing -> Nothing
    Nothing -> Nothing

getEndBody :: String -> Maybe String
getEndBody handle = case findString "</body>" handle of
   (Just a) -> Just $ fst $ splitAt a handle
   Nothing -> Nothing

getScript :: String -> Maybe String
getScript handle = case findString "<script" handle of
    (Just val1) -> case getEndScript $ snd $ splitAt val1 handle of
      (Just a) -> Just a
      Nothing -> Nothing
    Nothing -> Nothing

getEndScript :: String -> Maybe String
getEndScript handle = case findString "</script>" handle of
   (Just a) -> Just $ fst $ splitAt a handle
   Nothing -> Nothing

replaceAll :: Replace a => a -> Matches a -> a

main :: IO ()
main = do
  print (stripPrefix "foo" "foobar")
  --testFunc
  --handle <- readFile "./html_pages2/aaa2.txt"
  --let fstParse = parseTags handle
  --print (show (length fstParse))
  handle <- readFile "./html_pages2/aaaa2.html"
  let b = fromJust $ getBody handle
  print b
  let c = fromJust $ getScript b
  print c
  let d = subRegex (mkRegex "foo") "foobar" "123"

  -- cez rekurziu? kym nie je TagOpen "body" [], isTagOpen :: Tag str -> Bool , return()
  -- kym nie je TagClose "body" vezmi, potom return()
